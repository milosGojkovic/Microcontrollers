﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Prigusene_Oscilacije
{
    
    public partial class Podesavanja : Form
    {
        public Podesavanja()
        {
            InitializeComponent();
            napuni_portove();
        }
        
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            napuni_portove();
        }
        void napuni_portove()
        {
            listBox1.Items.Clear();
            foreach (string s in SerialPort.GetPortNames())
                listBox1.Items.Add(s);
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }
    }
}

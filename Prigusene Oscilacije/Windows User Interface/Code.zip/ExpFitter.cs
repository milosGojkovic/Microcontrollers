﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Extreme.Mathematics.Curves;
using Extreme.Mathematics.Curves.Nonlinear;
using Extreme.Mathematics;
using Extreme.Mathematics.LinearAlgebra;

namespace Prigusene_Oscilacije
{
    class ExpFitter
    {
      
        public double a, b, c, da, db, dc;
        public double[] xv;
        public double[] yv;
        public double[] dyv;
        private NonlinearCurveFitter fitter = new NonlinearCurveFitter();
        public void fituj()
        {
            var x = Vector.Create(xv);
            var y = Vector.Create(yv);
            var dy = Vector.Create(dyv);



            //ovde se pune vektori

            NonlinearCurve betaKriva = new MyCurve();
       
            fitter.Curve = betaKriva;
          
            fitter.XValues = x;
           
            fitter.YValues = y;
            fitter.InitialGuess = betaKriva.GetInitialFitParameters(x, y);
            fitter.WeightVector = null;
            fitter.Fit();
            var solution = fitter.BestFitParameters;
            var s = fitter.GetStandardDeviations();
            a = solution[0];
            b = solution[1];
            c = solution[2];
            da = s[0];
            db = s[1];
            dc = s[2];
        }
        public class MyCurve : NonlinearCurve
        {
            // Call the base constructor with the number of
            // parameters.
            public MyCurve() : base(3)
            {
                // It is convenient to set common starting values
                // for the curve parameters in the constructor:
                this.Parameters[0] = 1;
                this.Parameters[1] = 0.1;
                this.Parameters[2] = 0.1;

            }

            // The ValueAt method evaluates the function: a*e^(b/(x+c))
            override public double ValueAt(double x)
            {
                return Parameters[0] * Math.Exp(Parameters[1] * x) + Parameters[2];
            }

            // The SlopeAt method evaluates the derivative:
            override public double SlopeAt(double x)
            {
                return Parameters[0] * Math.Exp(Parameters[1] * x) * Parameters[1];
            }

            // The FillPartialDerivatives evaluates the partial derivatives
            // with respect to the curve parameters, and returns
            // the result in a vector. If you don't supply this method, 
            // a numerical approximation is used.
           
            override public void FillPartialDerivatives(double x, DenseVector<double> f)
            {
                f[0] = Math.Exp(Parameters[1] * x);
                f[1] = Parameters[0] * x * Math.Exp(Parameters[1] * x);
                f[2] = 1.0;

            }
            
        }
        
    }

}   
    


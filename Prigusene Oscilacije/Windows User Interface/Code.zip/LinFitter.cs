﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Extreme.Mathematics.Curves;
using Extreme.Mathematics.Curves.Nonlinear;
using Extreme.Mathematics;
using Extreme.Mathematics.LinearAlgebra;
namespace Prigusene_Oscilacije
{
    class LinFitter
    {
        public double a, b,da, db;
        public double[] xv;
        public double[] yv;
        public double[] dyv;
        private NonlinearCurveFitter fitter = new NonlinearCurveFitter();
        public void fituj()
        {
            var x = Vector.Create(xv);
            var y = Vector.Create(yv);
            var dy = Vector.Create(dyv);



            //ovde se pune vektori

            NonlinearCurve betaKriva = new MyCurve();

            fitter.Curve = betaKriva;

            fitter.XValues = x;

            fitter.YValues = y;
            fitter.InitialGuess = betaKriva.GetInitialFitParameters(x, y);
            fitter.WeightVector = null;
            fitter.Fit();
            var solution = fitter.BestFitParameters;
            var s = fitter.GetStandardDeviations();
            a = solution[0];
            b = solution[1];
            
            da = s[0];
            db = s[1];
          
        }
        public class MyCurve : NonlinearCurve
        {
            // Call the base constructor with the number of
            // parameters.
            public MyCurve() : base(2)
            {
                // It is convenient to set common starting values
                // for the curve parameters in the constructor:
                this.Parameters[0] = 0;
                this.Parameters[1] = 0;
                

            }

            // The ValueAt method evaluates the function: a*e^(b/(x+c))
            override public double ValueAt(double x)
            {
                return Parameters[0] +x*Parameters[1];
            }

            // The SlopeAt method evaluates the derivative:
            override public double SlopeAt(double x)
            {
                return Parameters[1];
            }

            // The FillPartialDerivatives evaluates the partial derivatives
            // with respect to the curve parameters, and returns
            // the result in a vector. If you don't supply this method, 
            // a numerical approximation is used.

            override public void FillPartialDerivatives(double x, DenseVector<double> f)
            {
                f[0] = 1;
                f[1] = x;
               

            }

        }

    }

}



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace Prigusene_Oscilacije
{
    class SessionClass
    {

        public double[] vrednosti = new double[4000];
        public int TimeBaseUS=5000;
        public double AmplitudeV=1.00;
        public double[] timebase = { 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000 };
        public double[] amplitude = { 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5 };
        public Int64 xScrollPosition = 0;
        public Int64 yScrollPosition = -2;
        public Double xScrollSize = 1000;
        public Double yScrollSize =4;
        public Boolean yScrollEnabled = true;
        public Boolean xScrollEnabled = true;
     
        public Boolean sel = false;



        public int
           
            HINTERVAL = 9, //index combobox-a timebase
            VINTERVAL = 8;//index combobox-a amplitude
        System.Drawing.Point[] Maksimumi = new System.Drawing.Point[20];//ovde se redjaju tacke iz tabele maksimuma
       
        public bool[] Kondenzatori = {false,false,false,false,false,false,true,true};//stanje kondenzatora
        public double[,] Kalemovi = new double[3,2]//stanje i vrednost kalemova
       {    {1,38},{0,38},{0,500}};
        public int freq=50, duty=10;//stanja comboboxeva freq i duty
        //treba dodati za selekciju
        public string podaci()
        {
            string s = "";
            foreach (bool b in Kondenzatori)
            {
                if (b)
                    s += "1";
                else s += "0";
            }
            if (Kalemovi[1, 0] == 1)
                s += "1";
            else
                s += "0";
            if (Kalemovi[2, 0] == 1)
                s += "1";
            else
                s += "0";

            return s;
        }
    }
    }

